#include <iostream>
using namespace std;

int main() {
    cout << "나의 첫 번째 C++ 프로그램" << endl;
    return 0;
}

